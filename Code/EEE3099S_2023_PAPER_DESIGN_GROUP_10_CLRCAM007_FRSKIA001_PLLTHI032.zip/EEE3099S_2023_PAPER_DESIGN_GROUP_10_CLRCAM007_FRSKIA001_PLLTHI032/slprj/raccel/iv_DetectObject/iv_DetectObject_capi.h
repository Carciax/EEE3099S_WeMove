#ifndef RTW_HEADER_iv_DetectObject_capi_h_
#define RTW_HEADER_iv_DetectObject_capi_h_
#include "iv_DetectObject.h"
extern void iv_DetectObject_InitializeDataMapInfo ( void ) ;
#endif
