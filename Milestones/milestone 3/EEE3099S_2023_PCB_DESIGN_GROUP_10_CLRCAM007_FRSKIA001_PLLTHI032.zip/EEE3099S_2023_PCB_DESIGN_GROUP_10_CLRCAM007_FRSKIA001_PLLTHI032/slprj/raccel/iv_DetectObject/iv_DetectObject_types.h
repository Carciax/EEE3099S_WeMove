#ifndef RTW_HEADER_iv_DetectObject_types_h_
#define RTW_HEADER_iv_DetectObject_types_h_
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
typedef struct gvf13cas0y_ gvf13cas0y ; typedef struct j3itycpy2js_
j3itycpy2js ; typedef struct j3itycpy2j_ j3itycpy2j ; typedef struct P_ P ;
#endif
